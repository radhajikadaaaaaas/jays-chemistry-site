
import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import ExpertSelector from './components/ExpertSelector';
import ChatInterface from './components/ChatInterface';
import { EXPERTS } from './constants';
import { ExpertProfile } from './types';

const App: React.FC = () => {
  const [selectedExpert, setSelectedExpert] = useState<ExpertProfile | null>(null);
  const [isApiKeyMissing, setIsApiKeyMissing] = useState(false);
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      setDarkMode(true);
      document.documentElement.classList.add('dark');
    }
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', event => {
      const newDarkMode = event.matches;
      setDarkMode(newDarkMode);
      if (newDarkMode) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    });
  }, []);

  useEffect(() => {
    if (!process.env.API_KEY) {
      setIsApiKeyMissing(true);
      console.error("CRITICAL: API_KEY environment variable is not set.");
    }
    // Pre-select the first expert by default if API key exists
    if (process.env.API_KEY && EXPERTS.length > 0 && !selectedExpert) {
      setSelectedExpert(EXPERTS[0]);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Run once on mount

  const toggleDarkMode = () => {
    setDarkMode(prevMode => {
      const newMode = !prevMode;
      if (newMode) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
      return newMode;
    });
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-gray-100 font-sans transition-colors duration-300">
      <Header darkMode={darkMode} toggleDarkMode={toggleDarkMode} />
      <main className="flex-grow flex flex-col container mx-auto sm:px-4 py-0 sm:py-2 md:py-6">
        {isApiKeyMissing && (
          <div className="m-4 p-4 bg-red-500 text-white rounded-md text-center shadow-lg">
            <strong>Configuration Error:</strong> The API_KEY environment variable is not set. This application requires an API key to function.
          </div>
        )}
        <ExpertSelector
          onSelectExpert={setSelectedExpert}
          selectedExpertId={selectedExpert?.id || null}
        />
        {selectedExpert && !isApiKeyMissing ? (
          <div className="mt-0 sm:mt-2 md:mt-6 flex-grow flex flex-col">
            <ChatInterface expert={selectedExpert} />
          </div>
        ) : !isApiKeyMissing && (
           <div className="mt-6 p-8 text-center text-gray-500 dark:text-gray-400 flex-grow flex flex-col justify-center items-center">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-16 h-16 mb-4 text-gray-400 dark:text-gray-500">
              <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09l2.846.813-.813 2.846a4.5 4.5 0 0 0-3.09 3.09ZM18.25 12h.008v.008h-.008V12ZM15.75 21h.008v.008h-.008V21Zm-7.5 0h.008v.008H8.25V21Z" />
            </svg>
            <p className="text-xl">Select an AI expert above to start chatting!</p>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
};

export default App;

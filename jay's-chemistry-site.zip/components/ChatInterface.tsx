
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Chat } from '@google/genai';
import { ExpertProfile, ChatMessage as ChatMessageTypeInternal, Sender, GroundingChunk, ExpertId, ChatTone } from '../types';
import { getGradeSpecificSuffix } from '../constants';
import { createChatSession, streamMessage } from '../geminiService';
import ChatMessageComponent from './ChatMessage';
import LoadingSpinner from '../LoadingSpinner';
import ErrorAlert from './ErrorAlert';

const SendIcon: React.FC<{className?: string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className={`w-5 h-5 ${className}`}>
    <path d="M3.105 3.105a.5.5 0 0 1 .707-.707L18.5 9.086a.5.5 0 0 1 0 .828L3.812 16.595a.5.5 0 0 1-.707-.707L16.188 10 3.105 3.105Z" />
  </svg>
);

const ClearIcon: React.FC<{className?: string}> = ({className}) => (
 <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={`w-5 h-5 ${className}`}>
  <path strokeLinecap="round" strokeLinejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12.56 0c.342.052.682.107 1.022.166m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
 </svg>
);

interface ChatInterfaceProps {
  expert: ExpertProfile;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ expert }) => {
  const [currentMessage, setCurrentMessage] = useState('');
  const [chatHistory, setChatHistory] = useState<ChatMessageTypeInternal[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const chatSessionRef = useRef<Chat | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [currentGrade, setCurrentGrade] = useState<number>(7); // Default to Grade 7
  const [currentTone, setCurrentTone] = useState<ChatTone>(ChatTone.CASUAL);
  const [showGrounding, setShowGrounding] = useState<boolean>(false);
  const [currentGroundingChunks, setCurrentGroundingChunks] = useState<GroundingChunk[]>([]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatHistory]);

  useEffect(() => {
    const initializeChat = async () => {
      setIsLoading(true);
      setError(null);
      setChatHistory([]); // Clear history when expert/grade/tone changes
      setCurrentMessage('');
      setShowGrounding(false);
      setCurrentGroundingChunks([]);
      try {
        const gradeSuffix = getGradeSpecificSuffix(currentGrade);
        let toneInstruction = '';
        if (currentTone === ChatTone.CASUAL) {
          toneInstruction = "IMPORTANT: Your tone should be casual, friendly, and relatable, using a Gen Z style of communication. Use modern slang where appropriate, be informal, and make the user feel like they're talking to a cool, knowledgeable peer. Lots of emojis and excitement!";
        } else if (currentTone === ChatTone.PROFESSIONAL) {
          toneInstruction = "IMPORTANT: Your tone should be professional, formal, and authoritative. Provide clear, concise, and accurate information. Avoid slang and overly casual language.";
        }
        const fullSystemInstruction = `${expert.systemInstruction} ${gradeSuffix} ${toneInstruction}`;
        const session = createChatSession(expert.model, fullSystemInstruction.trim());
        if (!session) {
          throw new Error("Failed to create chat session. The AI service might be unavailable or the API key is missing/invalid.");
        }
        chatSessionRef.current = session;
      } catch (e: any) {
        console.error("Initialization error:", e);
        setError(e.message || "Could not initialize chat with the expert.");
      } finally {
        setIsLoading(false);
      }
    };

    if (expert) {
      initializeChat();
    }

    return () => {
      // Cleanup if needed, e.g., if chat sessions have a close method
    };
  }, [expert, currentGrade, currentTone]);

  const handleSendMessage = useCallback(async (e?: React.FormEvent<HTMLFormElement>) => {
    if (e) e.preventDefault();
    if (!currentMessage.trim() || isLoading) return;

    const userMessage: ChatMessageTypeInternal = {
      id: `user-${Date.now()}`,
      text: currentMessage,
      sender: Sender.User,
      timestamp: new Date(),
    };
    setChatHistory(prev => [...prev, userMessage]);
    const messageToSend = currentMessage;
    setCurrentMessage('');
    setIsLoading(true);
    setError(null);
    setShowGrounding(false); 
    // Do not clear currentGroundingChunks here, let them persist until next successful response with new chunks

    if (!chatSessionRef.current) {
      setError("Chat session is not initialized. Please select an expert again or wait for initialization.");
      setIsLoading(false);
      return;
    }

    let fullAiResponse = "";
    let aiMessageId = `ai-${Date.now()}`;
    let tempAiMessageAdded = false;

    try {
      await streamMessage(
        chatSessionRef.current,
        messageToSend, // Use the captured message
        (streamResult) => { // onChunk
          fullAiResponse += streamResult.text;
          if (!tempAiMessageAdded) {
            setChatHistory(prev => [
              ...prev,
              { id: aiMessageId, text: fullAiResponse, sender: Sender.AI, timestamp: new Date() },
            ]);
            tempAiMessageAdded = true;
          } else {
            setChatHistory(prev => prev.map(msg => 
              msg.id === aiMessageId ? { ...msg, text: fullAiResponse, timestamp: new Date() } : msg
            ));
          }
          
          if (streamResult.groundingChunks && streamResult.groundingChunks.length > 0) {
            setShowGrounding(true);
            // Deduplicate and update grounding chunks
            setCurrentGroundingChunks(prevChunks => {
                const newChunks = streamResult.groundingChunks || [];
                const combined = [...prevChunks, ...newChunks];
                const uniqueUris = new Set<string>();
                return combined.filter(chunk => {
                    const uri = chunk.web?.uri || chunk.retrievedContext?.uri;
                    if (uri && !uniqueUris.has(uri)) {
                        uniqueUris.add(uri);
                        return true;
                    }
                    return false;
                });
            });
          }
        },
        (err) => { // onError
          console.error("Streaming error:", err);
          setError(`Error from AI: ${err.message}`);
          setIsLoading(false);
          // Remove temporary AI message if it exists and an error occurred
          if(tempAiMessageAdded){
            setChatHistory(prev => prev.filter(msg => msg.id !== aiMessageId));
          }
        },
        (finalResult) => { // onComplete
          // Final update handled by last onChunk call.
          setIsLoading(false);
        }
      );
    } catch (err: any) {
      console.error("Error sending message:", err);
      setError(`Failed to send message: ${err.message}`);
      setIsLoading(false);
      if(tempAiMessageAdded){
         setChatHistory(prev => prev.filter(msg => msg.id !== aiMessageId));
      }
      setChatHistory(prev => [...prev, {id: `err-${Date.now()}`, text: `System Error: ${err.message}`, sender: Sender.AI, timestamp: new Date()}]);
    }
  }, [currentMessage, isLoading, expert, chatSessionRef]);

  const handleClearChat = () => {
    setChatHistory([]);
    setError(null);
    setCurrentMessage('');
    setShowGrounding(false);
    setCurrentGroundingChunks([]);
    
    // Re-initialize chat session to clear server-side history if applicable
    const reInitializeChat = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const gradeSuffix = getGradeSpecificSuffix(currentGrade);
        let toneInstruction = '';
         if (currentTone === ChatTone.CASUAL) {
          toneInstruction = "IMPORTANT: Your tone should be casual, friendly, and relatable, using a Gen Z style of communication. Use modern slang where appropriate, be informal, and make the user feel like they're talking to a cool, knowledgeable peer. Lots of emojis and excitement!";
        } else if (currentTone === ChatTone.PROFESSIONAL) {
          toneInstruction = "IMPORTANT: Your tone should be professional, formal, and authoritative. Provide clear, concise, and accurate information. Avoid slang and overly casual language.";
        }
        const fullSystemInstruction = `${expert.systemInstruction} ${gradeSuffix} ${toneInstruction}`;
        
        const session = createChatSession(expert.model, fullSystemInstruction.trim());
        if (!session) {
          throw new Error("Failed to re-create chat session.");
        }
        chatSessionRef.current = session;
      } catch (e: any) {
        console.error("Re-initialization error:", e);
        setError(e.message || "Could not re-initialize chat.");
      } finally {
        setIsLoading(false);
      }
    };
    if (expert) reInitializeChat();
  };

  return (
    <div 
      className="flex flex-col bg-white dark:bg-gray-800 shadow-xl rounded-lg overflow-hidden w-full mx-auto transition-colors duration-300"
      style={{height: 'calc(100vh - 200px)'}} // Simplified height, adjust as needed
    >
      <div className={`p-3 sm:p-4 border-b ${expert.borderColor.replace('border-', 'border-') || 'border-gray-300 dark:border-gray-700'} flex flex-wrap items-center justify-between gap-2 sm:gap-4`}>
        <div className="flex items-center">
          <div className={`p-1 rounded-full ${expert.accentColor} text-white mr-2 sm:mr-3 flex-shrink-0 w-8 h-8 sm:w-10 sm:h-10 flex items-center justify-center`}>
            {React.cloneElement(expert.icon, { className: "w-5 h-5 sm:w-6 sm:h-6" })}
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-semibold text-gray-800 dark:text-white">{expert.name}</h2>
            <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400">{expert.tagline}</p>
          </div>
        </div>
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="flex items-center">
            <label htmlFor="grade-select" className="text-xs sm:text-sm text-gray-600 dark:text-gray-300 mr-1 sm:mr-2">Grade:</label>
            <select
              id="grade-select"
              value={currentGrade}
              onChange={(e) => setCurrentGrade(Number(e.target.value))}
              className="text-xs sm:text-sm bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-md p-1 sm:p-1.5 focus:ring-blue-500 focus:border-blue-500 transition-colors"
              aria-label="Select grade level"
            >
              {Array.from({ length: 16 }, (_, i) => i + 1).map(grade => (
                <option key={grade} value={grade}>{grade < 13 ? grade : (grade === 13 ? "1st yr Uni" : (grade === 14 ? "2nd yr Uni" : (grade === 15 ? "3rd yr Uni" : "4th yr Uni+")))}</option>
              ))}
            </select>
          </div>
           <div className="flex items-center">
            <label htmlFor="tone-select" className="text-xs sm:text-sm text-gray-600 dark:text-gray-300 mr-1 sm:mr-2">Tone:</label>
            <select
              id="tone-select"
              value={currentTone}
              onChange={(e) => setCurrentTone(e.target.value as ChatTone)}
              className="text-xs sm:text-sm bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-md p-1 sm:p-1.5 focus:ring-blue-500 focus:border-blue-500 transition-colors"
              aria-label="Select response tone"
            >
              <option value={ChatTone.CASUAL}>Casual (Gen Z)</option>
              <option value={ChatTone.PROFESSIONAL}>Professional</option>
            </select>
          </div>
          <button
            onClick={handleClearChat}
            className="p-1.5 sm:p-2 rounded-md text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 hover:text-gray-700 dark:hover:text-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-1 dark:focus:ring-offset-gray-800 focus:ring-red-500 transition-colors"
            title="Clear chat history"
            aria-label="Clear chat history"
          >
            <ClearIcon className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
        </div>
      </div>

      <div className="flex-grow p-3 sm:p-4 overflow-y-auto scrollbar-thin space-y-3 sm:space-y-4">
        {chatHistory.map((msg) => (
          <ChatMessageComponent
            key={msg.id}
            message={msg}
            expertName={msg.sender === Sender.AI ? expert.name : undefined}
            expertIcon={msg.sender === Sender.AI ? React.cloneElement(expert.icon, {className: "w-full h-full object-contain text-white"}) : undefined}
            expertAccentColor={msg.sender === Sender.AI ? expert.accentColor : undefined}
          />
        ))}
        {isLoading && (!chatHistory.length || chatHistory[chatHistory.length -1].sender === Sender.User) && (
           <div className="flex justify-start">
             <div className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full ${expert.accentColor} flex items-center justify-center text-white mr-2 flex-shrink-0 shadow-sm p-0.5 sm:p-1`}>
                {React.cloneElement(expert.icon, {className: "w-full h-full object-contain text-white"})}
             </div>
             <div className="p-2.5 sm:p-3 rounded-lg shadow-md bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-200 mr-auto">
                <LoadingSpinner size="w-5 h-5" color={`border-${expert.accentColor?.split('-')[1] || 'blue'}-500`} />
             </div>
           </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {showGrounding && currentGroundingChunks.length > 0 && (
        <div className="p-3 sm:p-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-750 max-h-32 overflow-y-auto scrollbar-thin">
          <h4 className="text-xs sm:text-sm font-semibold text-gray-600 dark:text-gray-300 mb-1.5 sm:mb-2">Sources:</h4>
          <ul className="space-y-1 text-xs sm:text-sm">
            {currentGroundingChunks.map((chunk, index) => {
              const uri = chunk.web?.uri || chunk.retrievedContext?.uri;
              const title = chunk.web?.title || chunk.retrievedContext?.title || uri;
              if (!uri) return null;
              try {
                const url = new URL(uri);
                return (
                  <li key={`${uri}-${index}`} className="truncate">
                    <a
                      href={url.toString()}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 dark:text-blue-400 hover:underline truncate"
                      title={title}
                    >
                      {index + 1}. {title}
                    </a>
                  </li>
                );
              } catch (e) { return null; }
            }).filter(Boolean)}
          </ul>
        </div>
      )}

      <form onSubmit={handleSendMessage} className="p-3 sm:p-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-750">
        <div className="flex items-center space-x-2 sm:space-x-3">
          <textarea
            rows={1}
            value={currentMessage}
            onChange={(e) => setCurrentMessage(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage();
              }
            }}
            placeholder={`Chat with ${expert.name} (Grade ${currentGrade})...`}
            className="flex-grow p-2 sm:p-2.5 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none resize-none scrollbar-thin text-sm sm:text-base bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 transition-colors"
            disabled={isLoading && !chatSessionRef.current}
            aria-label="Chat message input"
          />
          <button
            type="submit"
            disabled={isLoading || !currentMessage.trim()}
            className={`p-2 sm:p-2.5 rounded-lg text-white transition-colors duration-200
                        ${(isLoading || !currentMessage.trim())
                          ? 'bg-gray-400 dark:bg-gray-500 cursor-not-allowed'
                          : `${expert.accentColor} hover:${expert.accentColor.replace('500', '600').replace('600', '700')} focus:ring-2 focus:ring-offset-1 dark:focus:ring-offset-gray-750 ${expert.accentColor.replace('bg-','ring-')}`
                        }`}
            aria-label="Send message"
          >
            {isLoading ? <LoadingSpinner size="w-5 h-5" color="border-white" /> : <SendIcon className="w-5 h-5" />}
          </button>
        </div>
      </form>
      {error && <ErrorAlert message={error} onDismiss={() => setError(null)} />}
    </div>
  );
};

export default ChatInterface;

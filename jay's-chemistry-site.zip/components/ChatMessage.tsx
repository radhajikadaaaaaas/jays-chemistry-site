
import React from 'react';
import { ChatMessage as ChatMessageTypeInternal, Sender } from '../types'; // Renamed to avoid conflict

interface ChatMessageProps {
  message: ChatMessageTypeInternal;
  expertName?: string;
  expertIcon?: React.ReactNode; // Can be an img tag now
  expertAccentColor?: string;
}

// Basic Markdown to HTML Component
const SimpleMarkdown: React.FC<{ text: string }> = ({ text }) => {
  const processLine = (line: string): string => {
    // Bold: **text** or __text__
    line = line.replace(/\*\*(.*?)\*\*|__(.*?)__/g, '<strong>$1$2</strong>');
    // Italic: *text* or _text_
    line = line.replace(/\*(.*?)\*|_(.*?)_/g, '<em>$1$2</em>');
    // Strikethrough: ~~text~~
    line = line.replace(/~~(.*?)~~/g, '<del>$1</del>');
    // Inline code: `code`
    line = line.replace(/`([^`]+?)`/g, '<code class="bg-gray-200 dark:bg-gray-600 px-1 py-0.5 rounded text-sm font-mono">$1</code>');
    return line;
  };

  const blocks = text.split(/(\n```(?:\w*\n)?[\s\S]*?\n```\n?)/); // Split by code blocks
  const renderedHtml = blocks.map((block, index) => {
    if (index % 2 === 1) { // This is a code block part
      const match = block.match(/\n```(\w*)\n([\s\S]*?)\n```\n?/);
      if (match) {
        const lang = match[1];
        const code = match[2];
        // Basic syntax highlighting for common languages - extend as needed
        let highlightedCode = code.replace(/</g, '&lt;').replace(/>/g, '&gt;');
        return `<pre class="bg-gray-800 text-white p-3 my-2 rounded-md overflow-x-auto text-sm scrollbar-thin"><code class="language-${lang || 'plaintext'} font-mono">${highlightedCode}</code></pre>`;
      }
      return block; // Fallback for malformed block
    } else {
      // Process non-code block text
      return block
        .split('\n')
        .map(line => {
          if (line.startsWith('### ')) return `<h3 class="text-lg font-semibold mt-2 mb-1">${processLine(line.substring(4))}</h3>`;
          if (line.startsWith('## ')) return `<h2 class="text-xl font-semibold mt-3 mb-1">${processLine(line.substring(3))}</h2>`;
          if (line.startsWith('# ')) return `<h1 class="text-2xl font-semibold mt-4 mb-2">${processLine(line.substring(2))}</h1>`;
          if (line.match(/^(\s*)(-|\*|\d+\.)\s+/)) { // Improved list item detection for ul and ol
            const listPrefixMatch = line.match(/^(\s*)(-|\*|\d+\.)\s+/);
            const content = line.substring(listPrefixMatch![0].length);
            return `<li class="ml-4">${processLine(content)}</li>`;
          }
          if (line.trim() === '---' || line.trim() === '***' || line.trim() === '___') return '<hr class="my-2 border-gray-300 dark:border-gray-600" />';
          return processLine(line);
        })
        .join('<br />')
        .replace(/<br \/>(<h[1-3]|<li|<hr)/g, '$1') // Remove <br> before block elements
        .replace(/(<\/h[1-3]|<\/li>)<br \/>/g, '$1'); // Remove <br> after block elements
    }
  }).join('');
  
  // Wrap consecutive list items in <ul> or <ol>
  // This regex is a bit simplified; robust list handling can be complex.
  const wrapLists = (html: string) => {
    return html.replace(/(<li.*?>.*?<\/li>)(?:\s*<br \/>\s*(<li.*?>.*?<\/li>))*/gs, (match) => {
        // Determine if it's an ordered list by checking if the first li starts like an ordered list item (simplified)
        // This part needs more sophisticated detection if mixed lists or specific `ol` markers are used by Gemini
        const listItems = match.split(/<br \/>/).filter(item => item.trim().startsWith('<li')).join('');
        return `<ul class="list-disc pl-5 mb-2">${listItems}</ul>`; // Default to ul for now
    });
  };


  return <div dangerouslySetInnerHTML={{ __html: wrapLists(renderedHtml) }} />;
};


const ChatMessage: React.FC<ChatMessageProps> = ({ message, expertName, expertIcon, expertAccentColor }) => {
  const isUser = message.sender === Sender.User;
  const aiAccentColor = expertAccentColor || 'bg-gray-600';

  // Define a container size for the icon
  const iconContainerSize = "w-7 h-7 sm:w-8 sm:h-8";
  // const iconImageSize = "w-full h-full object-contain"; // This class is now applied by ChatInterface

  return (
    <div className={`flex mb-3 sm:mb-4 ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`flex items-end max-w-xl lg:max-w-2xl xl:max-w-3xl ${isUser ? 'flex-row-reverse' : ''}`}>
        {!isUser && (
          <div className={`${iconContainerSize} rounded-full ${aiAccentColor} flex items-center justify-center text-white mr-2 flex-shrink-0 shadow-sm p-0.5 sm:p-1`}>
            {expertIcon ? expertIcon : 'AI'}
          </div>
        )}
        <div
          className={`
            p-2.5 sm:p-3 rounded-lg shadow-md text-sm sm:text-base
            ${isUser ? 'bg-blue-500 dark:bg-blue-600 text-white ml-auto' : 'bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-200 mr-auto'}
          `}
        >
          {!isUser && expertName && <p className="text-xs font-semibold mb-1 opacity-80">{expertName}</p>}
          <div className="prose prose-sm dark:prose-invert max-w-none leading-relaxed">
            <SimpleMarkdown text={message.text} />
          </div>
          <p className={`text-xs mt-1.5 text-right ${isUser ? 'text-blue-200 dark:text-blue-300' : 'text-gray-500 dark:text-gray-400'}`}>
            {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </p>
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;

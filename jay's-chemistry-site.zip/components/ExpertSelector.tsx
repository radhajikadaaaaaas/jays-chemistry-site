import React from 'react';
import { EXPERTS } from '../constants';
import { ExpertId, ExpertProfile } from '../types';

interface ExpertSelectorProps {
  onSelectExpert: (expert: ExpertProfile) => void;
  selectedExpertId: ExpertId | null;
}

const ExpertCard: React.FC<{ expert: ExpertProfile; onSelect: () => void; isSelected: boolean }> = ({ expert, onSelect, isSelected }) => {
  // Determine a consistent size for the logo container
  const logoContainerSize = "w-10 h-10 sm:w-12 sm:h-12"; // Slightly larger to accommodate circular logos well
  const logoImageSize = "w-full h-full object-contain"; // Make image fill container while maintaining aspect ratio

  return (
    <button
      onClick={onSelect}
      className={`
        p-4 sm:p-6 rounded-xl shadow-lg transition-all duration-300 ease-in-out
        transform hover:-translate-y-1 focus:outline-none focus:ring-4 
        flex flex-col items-center text-center
        w-full sm:w-64 md:w-72
        ${isSelected ? `${expert.color} text-white ${expert.accentColor.replace('bg-', 'ring-')} ring-offset-2 dark:ring-offset-gray-900` : 'bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700 focus:ring-gray-300 dark:focus:ring-gray-600'}
      `}
      aria-pressed={isSelected}
    >
      <div className={`p-2 rounded-full mb-3 sm:mb-4 flex items-center justify-center ${logoContainerSize} ${isSelected ? expert.accentColor : expert.color}`}>
        {React.cloneElement(expert.icon, { className: logoImageSize })}
      </div>
      <h3 className="text-lg sm:text-xl font-semibold mb-1">{expert.name}</h3>
      <p className={`text-xs sm:text-sm ${isSelected ? 'text-gray-200' : 'text-gray-600 dark:text-gray-400'}`}>{expert.tagline}</p>
    </button>
  );
};

const ExpertSelector: React.FC<ExpertSelectorProps> = ({ onSelectExpert, selectedExpertId }) => {
  return (
    <div className="py-6 sm:py-8 px-4 bg-gray-100 dark:bg-gray-900 transition-colors duration-300">
      <h2 className="text-2xl sm:text-3xl font-bold text-center mb-6 sm:mb-8 text-gray-800 dark:text-white">Choose Your AI Expert</h2>
      <div className="flex flex-wrap justify-center items-stretch gap-4 sm:gap-6 md:gap-8">
        {EXPERTS.map((expert) => (
          <ExpertCard
            key={expert.id}
            expert={expert}
            onSelect={() => onSelectExpert(expert)}
            isSelected={selectedExpertId === expert.id}
          />
        ))}
      </div>
    </div>
  );
};

export default ExpertSelector;


import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-700 dark:bg-gray-800 text-gray-300 dark:text-gray-400 p-4 text-center mt-auto transition-colors duration-300">
      <p>&copy; {new Date().getFullYear()} Jay's Chemistry Site. For demonstration purposes only.</p>
    </footer>
  );
};

export default Footer;

import React from 'react';
import { ExpertId, ExpertProfile } from './types';

// Animated SVG Icon for Chemistry
const ChemistryIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" className={className}>
    <style>
      {`
        .chem-electron-path { animation: chem-orbit 6s linear infinite; transform-origin: center; }
        .chem-electron-path-2 { animation: chem-orbit 6s linear infinite; animation-delay: -2s; transform-origin: center; }
        .chem-electron-path-3 { animation: chem-orbit 6s linear infinite; animation-delay: -4s; transform-origin: center; }
        @keyframes chem-orbit { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}
    </style>
    <circle cx="50" cy="50" r="10" fill="currentColor" opacity="0.8"/>
    <g className="chem-electron-path">
      <ellipse cx="50" cy="50" rx="30" ry="15" stroke="currentColor" strokeWidth="2" fill="none" opacity="0.5"/>
      <circle cx="80" cy="50" r="4" fill="currentColor"/>
    </g>
    <g className="chem-electron-path-2" style={{ transform: 'rotate(60deg)'}}>
      <ellipse cx="50" cy="50" rx="30" ry="15" stroke="currentColor" strokeWidth="2" fill="none" opacity="0.5" transform="rotate(60 50 50)"/>
      <circle cx="80" cy="50" r="4" fill="currentColor" transform="rotate(60 50 50)"/>
    </g>
    <g className="chem-electron-path-3" style={{ transform: 'rotate(120deg)'}}>
      <ellipse cx="50" cy="50" rx="30" ry="15" stroke="currentColor" strokeWidth="2" fill="none" opacity="0.5" transform="rotate(120 50 50)"/>
      <circle cx="80" cy="50" r="4" fill="currentColor" transform="rotate(120 50 50)"/>
    </g>
  </svg>
);

// Animated SVG Icon for Biology
const BiologyIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" className={className}>
    <style>
      {`
        .bio-leaf { animation: bio-spin 10s linear infinite; transform-origin: center; }
        @keyframes bio-spin { from { transform: rotateY(0deg) rotateZ(0deg); } to { transform: rotateY(360deg) rotateZ(30deg); } }
      `}
    </style>
    <path className="bio-leaf" fill="currentColor" d="M50,5 C60,15 70,20 75,30 C85,45 80,60 70,70 C60,80 55,90 50,95 C45,90 40,80 30,70 C20,60 15,45 25,30 C30,20 40,15 50,5 Z M50,5 C50,25 40,30 30,45 C25,55 30,70 50,95 C70,70 75,55 70,45 C60,30 50,25 50,5 Z" opacity="0.8"/>
  </svg>
);

// Animated SVG Icon for Physics
const PhysicsIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" className={className}>
    <style>
      {`
        .phy-rocket { animation: phy-bob 2s ease-in-out infinite; transform-origin: bottom center; }
        .phy-flame { animation: phy-flicker 0.3s linear infinite; transform-origin: top center; }
        @keyframes phy-bob { 0%, 100% { transform: translateY(0px); } 50% { transform: translateY(-3px); } }
        @keyframes phy-flicker {
          0%, 100% { transform: scaleY(1) scaleX(1); opacity: 1; }
          50% { transform: scaleY(0.8) scaleX(1.1); opacity: 0.8; }
        }
      `}
    </style>
    <g className="phy-rocket">
      {/* Rocket Body */}
      <path d="M50 10 L60 30 L55 30 L55 60 L45 60 L45 30 L40 30 Z" fill="currentColor" opacity="0.8"/>
      {/* Fins */}
      <path d="M40 30 L30 40 L40 40 Z" fill="currentColor" opacity="0.7"/>
      <path d="M60 30 L70 40 L60 40 Z" fill="currentColor" opacity="0.7"/>
      <path d="M45 60 L40 70 L45 70 Z" fill="currentColor" opacity="0.7"/>
      <path d="M55 60 L60 70 L55 70 Z" fill="currentColor" opacity="0.7"/>
      {/* Nose cone */}
      <path d="M50 10 L45 20 L55 20 Z" fill="currentColor" opacity="0.9"/>
    </g>
    {/* Flame */}
    <g transform="translate(0 65)">
      <path className="phy-flame" d="M50 5 Q45 15 40 25 Q45 20 50 30 Q55 20 60 25 Q55 15 50 5 Z" fill="orange"/>
      <path className="phy-flame" style={{animationDelay: '-0.1s'}} d="M50 10 Q47 18 44 25 Q48 22 50 28 Q52 22 56 25 Q53 18 50 10 Z" fill="yellow" opacity="0.8"/>
    </g>
  </svg>
);


export const EXPERTS: ExpertProfile[] = [
  {
    id: ExpertId.CHEM,
    name: 'CHEMpro+',
    tagline: 'The AI version of Jay',
    description: 'Hi im your mini version of Jay',
    model: 'gemini-2.5-flash-preview-04-17',
    systemInstruction: 'You are ChemPro AI, a friendly and knowledgeable chemistry expert. Your goal is to explain chemistry concepts clearly and accurately.',
    icon: <ChemistryIcon />,
    color: 'bg-sky-500',
    accentColor: 'bg-sky-600',
    borderColor: 'border-sky-500',
  },
  {
    id: ExpertId.BIO,
    name: 'BIOpro+',
    tagline: 'Your lil Biology man',
    description: 'hi im a biology nerd.',
    model: 'gemini-2.5-flash-preview-04-17',
    systemInstruction: 'You are BioPro AI, an enthusiastic biology expert. You aim to make biology engaging and understandable for everyone.',
    icon: <BiologyIcon />,
    color: 'bg-emerald-500',
    accentColor: 'bg-emerald-600',
    borderColor: 'border-emerald-500',
  },
  {
    id: ExpertId.PHY,
    name: 'PHYpro+', // Corrected: removed trailing space
    tagline: 'Exploring the Universe, one equation at a time.',
    description: 'just a physics guy with a physics career',
    model: 'gemini-2.5-flash-preview-04-17',
    systemInstruction: 'You are PhyPro AI, a patient and insightful physics expert. You strive to demystify physics and show its relevance in the real world.',
    icon: <PhysicsIcon />,
    color: 'bg-purple-500',
    accentColor: 'bg-purple-600',
    borderColor: 'border-purple-500',
  },
];

export const getGradeSpecificSuffix = (grade: number): string => {
  let suffix = "";
  // Grades 1-11: no specific suffix
  if (grade >= 1 && grade <= 11) {
    return "";
  }
  
  // Suffixes for grades 12 and above
  if (grade === 12) { // Grade 12
    suffix = `Explain this for a high school student in grade ${grade}. You can use more technical terms and go into some depth.`;
  } else if (grade >= 13 && grade <= 14) { // Grades 13-14 (early undergraduate)
    suffix = `Explain this for an early undergraduate student (around grade ${grade}). Assume some prior knowledge in the subject.`;
  } else if (grade >= 15) { // Grades 15+ (advanced undergraduate/graduate)
    suffix = `Explain this for an advanced undergraduate or early graduate student (around grade ${grade}). Provide a detailed and nuanced explanation.`;
  }
  
  if (suffix) {
    return `IMPORTANT: ${suffix} Be engaging, encouraging, and ensure your response is easy to understand for this audience. Avoid overly complex jargon unless explained.`;
  }
  return ""; // Default empty string if no conditions met (should not happen with current grade range 1-16)
};

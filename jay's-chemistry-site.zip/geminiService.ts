
import { GoogleGenAI, Chat, GenerateContentResponse, GroundingChunk, Part } from '@google/genai';

const API_KEY = process.env.API_KEY;

let ai: GoogleGenAI | null = null;
if (API_KEY) {
  ai = new GoogleGenAI({ apiKey: API_KEY });
} else {
  console.error("API_KEY environment variable not set. AI features will be limited or non-functional.");
}

export const createChatSession = (modelName: string, systemInstruction: string): Chat | null => {
  if (!ai) {
    console.error("GoogleGenAI not initialized. Cannot create chat session.");
    return null;
  }
  try {
    const systemInstructionPart: Part = { text: systemInstruction };
    return ai.chats.create({
      model: modelName,
      config: {
        systemInstruction: systemInstructionPart, // Corrected: pass Part object
      },
    });
  } catch (error) {
    console.error("Error creating chat session:", error);
    return null;
  }
};

export interface StreamMessageResult {
  text: string;
  groundingChunks?: GroundingChunk[];
}

export const streamMessage = async (
  chat: Chat,
  messageText: string,
  onChunk: (chunkResult: StreamMessageResult) => void,
  onError: (error: Error) => void,
  onComplete: (finalResult: StreamMessageResult) => void
): Promise<void> => {
  if (!ai) {
    onError(new Error("GoogleGenAI not initialized. Cannot send message."));
    return;
  }
  try {
    const messagePart: Part = { text: messageText };
    const resultStream = await chat.sendMessageStream({ message: messagePart }); // Corrected: pass Part object
    
    let accumulatedText = "";
    let finalGroundingChunks: GroundingChunk[] | undefined = undefined;

    for await (const chunk of resultStream) { // chunk is GenerateContentResponse
      const chunkText = chunk.text; // Access text directly
      accumulatedText += chunkText;
      
      if (chunk.candidates?.[0]?.groundingMetadata?.groundingChunks) {
          finalGroundingChunks = chunk.candidates[0].groundingMetadata.groundingChunks;
      }
      onChunk({ text: chunkText, groundingChunks: finalGroundingChunks });
    }
    onComplete({ text: accumulatedText, groundingChunks: finalGroundingChunks });
  } catch (error) {
    console.error("Error streaming message:", error);
    onError(error instanceof Error ? error : new Error(String(error)));
  }
};

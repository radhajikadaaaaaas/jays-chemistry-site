
import React from 'react'; // Needed for React.ReactNode and React.ReactElement

export enum Sender {
  User = 'user',
  AI = 'ai',
}

export interface ChatMessage {
  id: string;
  text: string;
  sender: Sender;
  timestamp: Date;
}

export enum ExpertId {
  CHEM = 'chempro',
  BIO = 'biopro',
  PHY = 'phypro',
}

export enum ChatTone {
  CASUAL = 'casual',
  PROFESSIONAL = 'professional',
}

export interface ExpertProfile {
  id: ExpertId;
  name: string;
  tagline: string;
  description: string;
  model: string;
  systemInstruction: string;
  icon: React.ReactElement<{ className?: string }>;
  color: string; // Tailwind background color class e.g. bg-blue-500
  accentColor: string; // Tailwind background color class for accents e.g. bg-blue-600
  borderColor: string; // Tailwind border color class e.g. border-blue-500
}

export interface GroundingChunk {
  web?: {
    uri?: string; // Made optional
    title?: string; // Made optional
  };
  retrievedContext?: {
    uri?: string; // Made optional
    title?: string; // Made optional
  };
}
